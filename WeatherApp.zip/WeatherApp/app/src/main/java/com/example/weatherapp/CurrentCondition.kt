package com.example.weatherapp

data class CurrentCondition (
    val weather: List<WeatherCondition>,
    val main: Currents,
    val name: String,
)