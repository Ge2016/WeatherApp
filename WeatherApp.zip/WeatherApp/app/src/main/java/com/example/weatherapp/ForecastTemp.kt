package com.example.weatherapp

data class ForecastTemp (
    val day: Float,
    val max: Float,
    val min: Float
    )