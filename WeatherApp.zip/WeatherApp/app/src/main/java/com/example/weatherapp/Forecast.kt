package com.example.weatherapp

data class Forecast (
    val forecastWeather: List<DayForecast>
)