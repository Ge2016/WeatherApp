"# WeatherApp"

Intended for ICS 342 - Mobile Application Development - 1/14/22

We will be using the Android Studio platform for creating this weather app.